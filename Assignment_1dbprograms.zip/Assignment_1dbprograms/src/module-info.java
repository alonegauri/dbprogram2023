/**
 * 
 */
/**
 * @author Gauri Alone
 *
 */
module db_program {
	requires java.sql;
}