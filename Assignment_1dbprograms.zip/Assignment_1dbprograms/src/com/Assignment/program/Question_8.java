package com.Assignment.program;


import java.sql.*;


public class Question_8 {
	
public static void main(String[] args) {
Connection con;
CallableStatement cst;

try {
	 Class.forName("com.mysql.cj.jdbc.Driver");

		con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");

		
	 cst=con.prepareCall("{call updateprice(vivo,999)}");
	 cst.execute();
	 System.out.println("Price updated");
	 con.close();
}
catch(Exception e)
{
	 System.out.println(e);
}
}
}

