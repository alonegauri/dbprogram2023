
//Write a program to accept ram and rom, display list of mobiles of
//the ram-rom storage space combination

package com.Assignment.program;

import java.sql.*;
import java.util.*;

public class Question_7 {
public static void main(String[] args) {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	
	Scanner sc=new Scanner(System.in);
	String rom,ram;
	
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
	
		con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");

		pst=con.prepareStatement("select modelname,ram,rom  from Mobiles where ram=? and rom=?");
		
		System.out.println("Enter ram: ");
		ram=sc.nextLine();
		System.out.println("Enter rom: ");
		rom=sc.nextLine();
		
		pst.setString(1,ram);
		pst.setString(2,rom);
		rs=pst.executeQuery();
		
		while(rs.next())
		{
			System.out.println(rs.getString("modelname"));
		}
		con.close();
		sc.close();
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
}
}
