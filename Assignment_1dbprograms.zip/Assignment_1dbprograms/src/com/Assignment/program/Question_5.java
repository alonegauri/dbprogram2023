

//Write a program to accept prodid & new price and update price in
//the mobile data in the table if found else display "mobile does not
//exist"


package com.Assignment.program;


import java.sql.*;
import java.util.Scanner;

public class Question_5 {
	public static void main(String[] args) {
		Connection con;
		PreparedStatement pst;
		
		
		Scanner sc= new Scanner(System.in);
		
		int pid;
		float price;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");
			pst=con.prepareStatement("update Mobiles set price=? where prodid=?");
			
			System.out.print("Enter product id: ");
			pid=sc.nextInt();
			System.out.println("Enter new price: ");
			price=sc.nextFloat();
			
			pst.setFloat(1, price);
			pst.setInt(2, pid);
			
			int cnt=pst.executeUpdate();
			System.out.println(cnt);
			
			if(cnt==1)	
			System.out.println("Price changed successfully");
			else
				System.out.println("mobile does not exist");
			
			con.close();
			sc.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
	}

}

