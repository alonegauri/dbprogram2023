//Take field as an input like rom and display all mobiles in the
//descending order of the that field.

package com.Assignment.program;

import java.sql.*;
import java.util.Scanner;

public class Question_11 {
public static void main(String[] args) {
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	String rom;
	
	Scanner sc= new Scanner(System.in);
	
	try
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		

		con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");

		
		
		pst=con.prepareStatement("select modelname from Mobiles where rom=? order by rom desc");
		
		System.out.println("Enter rom: ");
		rom=sc.nextLine();
		
		pst.setString(1,rom);
		rs=pst.executeQuery();
		
		while(rs.next())
		{
			System.out.println(rs.getString("modelname"));
		}
		
		con.close();
		sc.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
}
