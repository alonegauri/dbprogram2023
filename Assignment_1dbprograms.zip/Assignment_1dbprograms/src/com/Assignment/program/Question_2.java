//Write a program to show list of all Mobiles

package com.Assignment.program;

import java.sql.*;

public class Question_2 {
public static void main(String[] args) {
	Connection con;
	Statement st;
	ResultSet rs;
	
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		  con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");
		  
		
		st=con.createStatement();
		rs=st.executeQuery("select * from Mobiles");
		
		while(rs.next())
		{
			System.out.println(rs.getString("modelname")+" | ");
			System.out.println(rs.getString("company"));
		}
		con.close();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
}

