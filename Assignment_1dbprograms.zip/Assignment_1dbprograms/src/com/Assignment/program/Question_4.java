
//Write a program to accept company like "samsung" and display list
//of mobiles of that category in the ascending order of price


package com.Assignment.program;

import java.sql.*;
import java.util.Scanner;

public class Question_4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Connection con;
		PreparedStatement pst;
		ResultSet rs;
		
		String comp;
		
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
	    	con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");
			  
			pst=con.prepareStatement("select modelname from Mobiles where company=? order by price asc");
			
			System.out.println("Enter company name: ");
			comp=sc.nextLine();
			
			pst.setString(1, comp);
			rs=pst.executeQuery();
			
			while(rs.next())
			{
				System.out.println(rs.getString("modelname"));
			}
			
			con.close();
			sc.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}


