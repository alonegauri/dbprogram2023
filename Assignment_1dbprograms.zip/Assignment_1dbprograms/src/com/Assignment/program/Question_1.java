
//Write a program to take new mobile data as input and add mobile
//to the DB table

package com.Assignment.program;

import java.util.Scanner;
import java.sql.*;

public class Question_1 {
public static void main(String[] args) {
	  Scanner sc= new Scanner(System.in);
	  
	Connection con ;
	PreparedStatement pst;
	int pid;
	String model_nm, comp,conn,ram,rom,color,screen,battery,processor;
	float price,ratings;
	
	try 
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		  con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");
		  
		pst=con.prepareStatement("insert into Mobiles values(?,?,?,?,?,?,?,?,?,?,?,?)");
		
		System.out.println("Enter product id: ");
		pid=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter model name: ");
		model_nm=sc.nextLine();
		System.out.println("Enter company :");
		comp=sc.nextLine();
		System.out.println("Enter connectivity(4G/5G): ");
		conn=sc.nextLine();
		System.out.println("Enter RAM: ");
		ram=sc.nextLine();
		System.out.println("Enter ROM: ");
		rom=sc.nextLine();
		System.out.println("Enter color: ");
		color=sc.nextLine();
		System.out.println("Enter display of screen: ");
		screen=sc.nextLine();
		System.out.println("Enter battery : ");
		battery=sc.nextLine();
		System.out.println("Enter processor: ");
		processor=sc.nextLine();
		System.out.println("Enter price: ");
		price=sc.nextFloat();
		System.out.println("Enter ratings: ");
		ratings=sc.nextFloat();
		
		pst.setInt(1, pid);
		pst.setString(2, model_nm);
		pst.setString(3,comp);
		pst.setString(4,conn);
		pst.setString(5,ram);
		pst.setString(6, rom);
		pst.setString(7, color);
		pst.setString(8, screen);
		pst.setString(9,battery);
		pst.setString(10, processor);
		pst.setFloat(11, price);
		pst.setFloat(12, ratings);
		pst.executeUpdate();
		
		System.out.println("Data entered sucessfully");
		con.close();
		sc.close();
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
	
	
}
}

