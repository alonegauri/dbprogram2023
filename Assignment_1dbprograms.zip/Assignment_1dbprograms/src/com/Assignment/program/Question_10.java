//Write a program to display group by information - brand, total
//models under the company, average price and average rating


package com.Assignment.program;

import java.sql.*;
import java.util.Scanner;

public class Question_10 { 
	public static void main(String[] args) {
		Connection con;
		Statement st;
		ResultSet rs;
		
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");

			con=DriverManager.getConnection("jdbc:mysql://b3uphzzhj0nev387uwjh-mysql.services.clever-cloud.com:3306/b3uphzzhj0nev387uwjh?user=u5nnu374vo1psnnx&password=APWnaH0x8oSWwOhAvHqI");

			

		    st=con.createStatement();
			rs=st.executeQuery("select * from Mobiles where group by AVG(price) and AVG(ratings) ");
			while(rs.next())
			{
				System.out.println(rs.getString("company")+" | "+rs.getString("modelname")+" | ");
			}
			con.close();
			
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
